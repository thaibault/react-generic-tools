if(typeof window==='undefined'||window===null)var window=(typeof globalThis==='undefined'||globalThis===null)?{}:globalThis;import "@jest/globals";
import { globalContext as __WEBPACK_EXTERNAL_MODULE_clientnode_globalContext__ } from "clientnode";
import { act as __WEBPACK_EXTERNAL_MODULE_react_act__, createElement as __WEBPACK_EXTERNAL_MODULE_react_createElement__ } from "react";
import { flushSync as __WEBPACK_EXTERNAL_MODULE_react_dom_c0b5c364_flushSync__ } from "react-dom";
import { createRoot as __WEBPACK_EXTERNAL_MODULE_react_dom_client_82ef521c_createRoot__ } from "react-dom/client";

;// external "@jest/globals"

;// external "clientnode"

;// external "react"

;// external "react-dom"

;// external "react-dom/client"

;// ./testHelper.ts
// #!/usr/bin/env babel-node
// -*- coding: utf-8 -*-
/** @module testHelper *//* !
    region header
    [Project page](https://tsickert.com/react-material-input)

    Copyright Torben Sickert (info["~at~"]tsickert.com) 16.12.2012

    License
    -------

    This library written by Torben Sickert stands under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/// region imports
function _typeof(o){"@babel/helpers - typeof";return _typeof="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(o){return typeof o}:function(o){return o&&"function"==typeof Symbol&&o.constructor===Symbol&&o!==Symbol.prototype?"symbol":typeof o},_typeof(o)}function _toConsumableArray(r){return _arrayWithoutHoles(r)||_iterableToArray(r)||_unsupportedIterableToArray(r)||_nonIterableSpread()}function _nonIterableSpread(){throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}function _unsupportedIterableToArray(r,a){if(r){if("string"==typeof r)return _arrayLikeToArray(r,a);var t={}.toString.call(r).slice(8,-1);return"Object"===t&&r.constructor&&(t=r.constructor.name),"Map"===t||"Set"===t?Array.from(r):"Arguments"===t||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)?_arrayLikeToArray(r,a):void 0}}function _iterableToArray(r){if("undefined"!=typeof Symbol&&null!=r[Symbol.iterator]||null!=r["@@iterator"])return Array.from(r)}function _arrayWithoutHoles(r){if(Array.isArray(r))return _arrayLikeToArray(r)}function _arrayLikeToArray(r,a){(null==a||a>r.length)&&(a=r.length);for(var e=0,n=Array(a);e<a;e++)n[e]=r[e];return n}function ownKeys(e,r){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var o=Object.getOwnPropertySymbols(e);r&&(o=o.filter(function(r){return Object.getOwnPropertyDescriptor(e,r).enumerable})),t.push.apply(t,o)}return t}function _objectSpread(e){for(var r=1;r<arguments.length;r++){var t=null!=arguments[r]?arguments[r]:{};r%2?ownKeys(Object(t),!0).forEach(function(r){_defineProperty(e,r,t[r])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):ownKeys(Object(t)).forEach(function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(t,r))})}return e}function _defineProperty(e,r,t){return(r=_toPropertyKey(r))in e?Object.defineProperty(e,r,{value:t,enumerable:!0,configurable:!0,writable:!0}):e[r]=t,e}function _toPropertyKey(t){var i=_toPrimitive(t,"string");return"symbol"==_typeof(i)?i:i+""}function _toPrimitive(t,r){if("object"!=_typeof(t)||!t)return t;var e=t[Symbol.toPrimitive];if(void 0!==e){var i=e.call(t,r||"default");if("object"!=_typeof(i))return i;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===r?String:Number)(t)};__WEBPACK_EXTERNAL_MODULE_clientnode_globalContext__.IS_REACT_ACT_ENVIRONMENT=true;var prepareTestEnvironment=function prepareTestEnvironment(currentBeforeEach,currentAfterEach){var root=null;var result={container:null,render:function render(component,flush){var _result$container;if(flush===void 0){flush=true}__WEBPACK_EXTERNAL_MODULE_react_act__(function(){if(root){if(flush)__WEBPACK_EXTERNAL_MODULE_react_dom_c0b5c364_flushSync__(function(){if(root)root.render(component)});else root.render(component);}else console.error("You call \"render\" outside a testing context.")});return(_result$container=result.container)!==null&&_result$container!==void 0&&_result$container.childNodes.length?result.container.childNodes[0]:result.container},runHook:function runHook(hook,/*
                eslint-disable @typescript-eslint/no-useless-default-assignment
            */givenOptions/*
                eslint-enable @typescript-eslint/no-useless-default-assignment
            */){if(givenOptions===void 0){givenOptions={}}var options=_objectSpread({flush:true,parameters:[],wrapper:null},givenOptions);var hookResult={};var TestComponent=function TestComponent(_ref){var parameters=_ref.parameters;hookResult.value=hook.apply(void 0,_toConsumableArray(parameters));return null};var render=function render(){for(var _len=arguments.length,parameters=new Array(_len),_key=0;_key<_len;_key++){parameters[_key]=arguments[_key]}var componentElement=__WEBPACK_EXTERNAL_MODULE_react_createElement__(TestComponent,{parameters:parameters});if(options.wrapper)componentElement=__WEBPACK_EXTERNAL_MODULE_react_createElement__(options.wrapper.component,_objectSpread(_objectSpread({},options.wrapper.properties||{}),{},{children:componentElement}));__WEBPACK_EXTERNAL_MODULE_react_act__(function(){if(root){if(options.flush)__WEBPACK_EXTERNAL_MODULE_react_dom_c0b5c364_flushSync__(function(){if(root)root.render(componentElement)});else root.render(componentElement);}else console.error("You call \"render\" outside a testing context.")})};render.apply(void 0,_toConsumableArray(options.parameters));return{result:hookResult,render:render}}};currentBeforeEach(function(){result.container=document.createElement("div");result.container.setAttribute("class","test-wrapper");document.body.appendChild(result.container);if(!root)__WEBPACK_EXTERNAL_MODULE_react_act__(function(){root=__WEBPACK_EXTERNAL_MODULE_react_dom_client_82ef521c_createRoot__(result.container)})});currentAfterEach(function(){var _result$container2;if(root)__WEBPACK_EXTERNAL_MODULE_react_act__(function(){if(root)root.unmount();root=null});(_result$container2=result.container)===null||_result$container2===void 0||_result$container2.remove();result.container=null});return result};/* harmony default export */ var testHelper = (prepareTestEnvironment);
export { testHelper as default, prepareTestEnvironment };
