import { afterEach, beforeEach } from '@jest/globals';
import { TestEnvironment } from './type';
export declare const prepareTestEnvironment: (currentBeforeEach: typeof beforeEach, currentAfterEach: typeof afterEach) => TestEnvironment;
export default prepareTestEnvironment;
