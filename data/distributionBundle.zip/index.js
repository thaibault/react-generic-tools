if(typeof window==='undefined'||window===null)var window=(typeof globalThis==='undefined'||globalThis===null)?{}:globalThis;import { paginate as __WEBPACK_EXTERNAL_MODULE_clientnode_paginate__ } from "clientnode";
import { useMemo as __WEBPACK_EXTERNAL_MODULE_react_useMemo__, useState as __WEBPACK_EXTERNAL_MODULE_react_useState__ } from "react";
import { Fragment as __WEBPACK_EXTERNAL_MODULE_react_jsx_runtime_00f484c1_Fragment__, jsx as __WEBPACK_EXTERNAL_MODULE_react_jsx_runtime_00f484c1_jsx__ } from "react/jsx-runtime";

;// external "clientnode"

;// external "react"

;// external "react/jsx-runtime"

;// ./index.tsx
// #!/usr/bin/env babel-node
// -*- coding: utf-8 -*-
/** @module Generic *//* !
    region header
    [Project page](https://torben.website/react-material-input)

    Copyright Torben Sickert (info["~at~"]torben.website) 16.12.2012

    License
    -------

    This library written by Torben Sickert stands under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/// region imports
function _typeof(o){"@babel/helpers - typeof";return _typeof="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(o){return typeof o}:function(o){return o&&"function"==typeof Symbol&&o.constructor===Symbol&&o!==Symbol.prototype?"symbol":typeof o},_typeof(o)}var _excluded=["boundaryCount","className","disabled","hideNextButton","hidePrevButton","page","pageSize","render","showFirstButton","showLastButton","siblingCount","total"];function ownKeys(e,r){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var o=Object.getOwnPropertySymbols(e);r&&(o=o.filter(function(r){return Object.getOwnPropertyDescriptor(e,r).enumerable})),t.push.apply(t,o)}return t}function _objectSpread(e){for(var r=1;r<arguments.length;r++){var t=null!=arguments[r]?arguments[r]:{};r%2?ownKeys(Object(t),!0).forEach(function(r){_defineProperty(e,r,t[r])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):ownKeys(Object(t)).forEach(function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(t,r))})}return e}function _defineProperty(e,r,t){return(r=_toPropertyKey(r))in e?Object.defineProperty(e,r,{value:t,enumerable:!0,configurable:!0,writable:!0}):e[r]=t,e}function _toPropertyKey(t){var i=_toPrimitive(t,"string");return"symbol"==_typeof(i)?i:i+""}function _toPrimitive(t,r){if("object"!=_typeof(t)||!t)return t;var e=t[Symbol.toPrimitive];if(void 0!==e){var i=e.call(t,r||"default");if("object"!=_typeof(i))return i;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===r?String:Number)(t)}function _objectWithoutProperties(e,t){if(null==e)return{};var o,r,i=_objectWithoutPropertiesLoose(e,t);if(Object.getOwnPropertySymbols){var n=Object.getOwnPropertySymbols(e);for(r=0;r<n.length;r++)o=n[r],-1===t.indexOf(o)&&{}.propertyIsEnumerable.call(e,o)&&(i[o]=e[o])}return i}function _objectWithoutPropertiesLoose(r,e){if(null==r)return{};var t={};for(var n in r)if({}.hasOwnProperty.call(r,n)){if(-1!==e.indexOf(n))continue;t[n]=r[n]}return t}function _slicedToArray(r,e){return _arrayWithHoles(r)||_iterableToArrayLimit(r,e)||_unsupportedIterableToArray(r,e)||_nonIterableRest()}function _nonIterableRest(){throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}function _unsupportedIterableToArray(r,a){if(r){if("string"==typeof r)return _arrayLikeToArray(r,a);var t={}.toString.call(r).slice(8,-1);return"Object"===t&&r.constructor&&(t=r.constructor.name),"Map"===t||"Set"===t?Array.from(r):"Arguments"===t||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)?_arrayLikeToArray(r,a):void 0}}function _arrayLikeToArray(r,a){(null==a||a>r.length)&&(a=r.length);for(var e=0,n=Array(a);e<a;e++)n[e]=r[e];return n}function _iterableToArrayLimit(r,l){var t=null==r?null:"undefined"!=typeof Symbol&&r[Symbol.iterator]||r["@@iterator"];if(null!=t){var e,n,i,u,a=[],f=!0,o=!1;try{if(i=(t=t.call(r)).next,0===l){if(Object(t)!==t)return;f=!1}else for(;!(f=(e=i.call(t)).done)&&(a.push(e.value),a.length!==l);f=!0);}catch(r){o=!0,n=r}finally{try{if(!f&&null!=t.return&&(u=t.return(),Object(u)!==u))return}finally{if(o)throw n}}return a}}function _arrayWithHoles(r){if(Array.isArray(r))return r};// endregion
// region hooks
/**
 * Custom hook to memorize any values with a default empty array. Useful if
 * using previous constant complex object within a render function.
 * @param value - Value to memorize.
 * @param dependencies - Optional dependencies when to update given value.
 * @returns Given cached value.
 */function useMemorizedValue(value){for(var _len=arguments.length,dependencies=new Array(_len>1?_len-1:0),_key=1;_key<_len;_key++){dependencies[_key-1]=arguments[_key]}return __WEBPACK_EXTERNAL_MODULE_react_useMemo__(function(){return value},dependencies)}/**
 * Use state wrapper to deal with references. It only sets a new state if the
 * given reference isn't null.
 * @param initialValue - To set state to.
 * @returns Whatever "useState" would return.
 */var useReferenceState=function useReferenceState(initialValue){var _useState=__WEBPACK_EXTERNAL_MODULE_react_useState__(initialValue),_useState2=_slicedToArray(_useState,2),value=_useState2[0],setValue=_useState2[1];return[value,useMemorizedValue(function(reference){if(reference!==null)setValue(reference)})]};// endregion
// region components
var Pagination=function Pagination(_ref){var _ref$boundaryCount=_ref.boundaryCount,boundaryCount=_ref$boundaryCount===void 0?1:_ref$boundaryCount,_ref$className=_ref.className,className=_ref$className===void 0?"pagination":_ref$className,_ref$disabled=_ref.disabled,disabled=_ref$disabled===void 0?false:_ref$disabled,_ref$hideNextButton=_ref.hideNextButton,hideNextButton=_ref$hideNextButton===void 0?false:_ref$hideNextButton,_ref$hidePrevButton=_ref.hidePrevButton,hidePrevButton=_ref$hidePrevButton===void 0?false:_ref$hidePrevButton,_ref$page=_ref.page,page=_ref$page===void 0?1:_ref$page,_ref$pageSize=_ref.pageSize,pageSize=_ref$pageSize===void 0?5:_ref$pageSize,_ref$render=_ref.render,render=_ref$render===void 0?function(_ref2){var page=_ref2.page,type=_ref2.type;return String(page)||type}:_ref$render,_ref$showFirstButton=_ref.showFirstButton,showFirstButton=_ref$showFirstButton===void 0?false:_ref$showFirstButton,_ref$showLastButton=_ref.showLastButton,showLastButton=_ref$showLastButton===void 0?false:_ref$showLastButton,_ref$siblingCount=_ref.siblingCount,siblingCount=_ref$siblingCount===void 0?1:_ref$siblingCount,_ref$total=_ref.total,total=_ref$total===void 0?100:_ref$total,additionalProperties=_objectWithoutProperties(_ref,_excluded);return total>(pageSize!==null&&pageSize!==void 0?pageSize:1)?/*#__PURE__*/__WEBPACK_EXTERNAL_MODULE_react_jsx_runtime_00f484c1_jsx__("div",{className:className,children:/*#__PURE__*/__WEBPACK_EXTERNAL_MODULE_react_jsx_runtime_00f484c1_jsx__("ul",_objectSpread(_objectSpread({},additionalProperties),{},{children:__WEBPACK_EXTERNAL_MODULE_clientnode_paginate__({boundaryCount:boundaryCount,disabled:disabled,hideNextButton:hideNextButton,hidePrevButton:hidePrevButton,page:page,pageSize:pageSize,showFirstButton:showFirstButton,showLastButton:showLastButton,siblingCount:siblingCount,total:total}).map(function(item){return/*#__PURE__*/__WEBPACK_EXTERNAL_MODULE_react_jsx_runtime_00f484c1_jsx__("li",{children:render(item)},item.type+(typeof item.page==="number"?"-".concat(String(item.page)):""))})}))}):/*#__PURE__*/__WEBPACK_EXTERNAL_MODULE_react_jsx_runtime_00f484c1_jsx__(__WEBPACK_EXTERNAL_MODULE_react_jsx_runtime_00f484c1_Fragment__,{})};// endregion
export { Pagination, useMemorizedValue, useReferenceState };
