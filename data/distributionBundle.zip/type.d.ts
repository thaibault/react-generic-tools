import { Page, PaginateOptions } from 'clientnode/type';
import { FunctionComponent, FunctionComponentElement, PropsWithChildren, ReactElement, ReactNode, SyntheticEvent, ValidationMap, WeakValidationMap } from 'react';
export interface GenericEvent<T = unknown> extends SyntheticEvent {
    detail?: T;
}
/**
 * Fills lack of reacts flexible function component return values (ReactNode).
 * Copied reacts component type but with "ReactNode" instead of "ReactElement"
 * as allowed return value.
 */
export interface GenericFunctionComponent<P = {}> {
    (props: PropsWithChildren<P>, context?: any): ReactNode;
    propTypes?: WeakValidationMap<P>;
    contextTypes?: ValidationMap<any>;
    defaultProps?: Partial<P>;
    displayName?: string;
}
export interface TestHookWrapper<P extends Array<unknown> = Array<unknown>, WP extends {
    children: FunctionComponentElement<{
        parameters: P;
    }> | ReactElement;
} = {
    children: FunctionComponentElement<{
        parameters: P;
    }> | ReactElement;
}> {
    component: FunctionComponent<WP>;
    properties?: WP;
}
export interface TestHookResult<R = unknown, P extends Array<unknown> = Array<unknown>> {
    result: {
        value: R;
    };
    render: (...parameters: P) => void;
}
export interface TestHookOptions<P extends Array<unknown> = Array<unknown>, WP extends {
    children: FunctionComponentElement<{
        parameters: P;
    }> | ReactElement;
} = {
    children: FunctionComponentElement<{
        parameters: P;
    } | ReactElement>;
}> {
    parameters: P;
    wrapper?: null | TestHookWrapper<P, WP>;
    flush?: boolean;
}
export interface TestEnvironment {
    container: HTMLDivElement | null;
    render: <T = HTMLElement>(component: ReactNode) => null | T;
    runHook: <R = unknown, P extends Array<unknown> = Array<unknown>, WP extends {
        children: FunctionComponentElement<{
            parameters: P;
        }> | ReactElement;
    } = {
        children: FunctionComponentElement<{
            parameters: P;
        }> | ReactElement;
    }>(hook: (...parameters: P) => R, options: Partial<TestHookOptions<P, WP>>) => TestHookResult<R, P>;
}
export interface PaginationProperties extends PaginateOptions {
    className: string;
    render: (page: Page) => ReactNode;
}
