import { FunctionComponent } from 'react';
import { PaginationProperties } from './type';
/**
 * Custom hook to memorize any values with a default empty array. Useful if
 * using previous constant complex object within a render function.
 * @param value - Value to memorize.
 * @param dependencies - Optional dependencies when to update given value.
 * @returns Given cached value.
 */
export declare const useMemorizedValue: <T = unknown>(value: T, ...dependencies: Array<unknown>) => T;
export declare const Pagination: FunctionComponent<Partial<PaginationProperties>>;
